package com.azizerel.javablog.constraints;

/**
 * created by Abdulaziz Erel on 21:22 10.02.2020
 **/
public class ArticleConstraints {
    public static final String  TABLE_NAME = "BLOG_ARTICLE";

}
