package com.azizerel.javablog.common;

/**
 * created by Abdulaziz Erel on 21:19 10.02.2020
 **/
public class ArticleModel extends BaseModel {
}
