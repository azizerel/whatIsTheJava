package com.azizerel.javablog.common;

/**
 * created by Abdulaziz Erel on 21:18 10.02.2020
 **/
public class BaseModel {

    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
